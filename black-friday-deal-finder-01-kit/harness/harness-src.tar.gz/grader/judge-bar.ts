// A judged final's bar games (agent-fun/judge-bar/v1, JUDGE_BAR_FORMAT): once a final heat has settled, every paid
// entry of a bundle naming `harness.judge.bar` plays the bundle's sealed bar artifact in `games` more games, each judged
// in both slot orders exactly as that final's playoff is judged, and beats the bar iff it takes more than half of their
// points. The bar games never enter a heat record (grader/judge-heat.ts's v2 to v6 bytes are untouched): they are their
// own small heat with this record. Pure: no clock, no I/O and no database; the bar job (grader/judge-bar-job.ts) sends
// each call through the judge heat runner, keeps what came back as a bar call (judgeBarCallOf) and stores the record
// judgeBarRecordOf builds, canonical JSON (sim/canonical.ts) named by its sha256. It is imported by cli/verify-result.ts,
// so it stays off server/judging/judge-measures.ts (tests/unit/cli-bundle-no-judge-candidates.test.ts): it reads
// judge-heat.ts and the pure judge contracts that module already reads, nothing else.
//
//   the setup      JudgeBarSetup, fixed before the first call: the final phase's id; the settled final heat record it
//                  judges like (`final_heat`: its sha256 and format, a final's v2, v4, v5 or v6); the bar (`bar`: its
//                  name, the sealed bar dir's tree digest, its artifact's sha256 and bytes, and `games`, 1 to
//                  PROGRAM_JUDGE_BAR_MAX_GAMES); the subjects, one per distinct artifact among the entries it judges, in place
//                  order, each its artifact's sha256 and bytes and its entries (code-unit order, no entry twice, never the
//                  bar's own artifact); the final record's `judges` and `panel`, copied verbatim (a panel exactly on a
//                  v5 or v6 final); the judge prompt's sha256; and, on a dossier final judged on views, `judge_view` (the
//                  final's policy, each subject's and the bar's artifact to its view blob, nothing else)
//   the seats      who judges a game, as the final's playoff is judged: a v2 or v4 final's one judge (its `judges` hold
//                  exactly one), seat 0; a v5 or v6 final's drawn panel, judges 0, 1 and 2 (JUDGE_PANEL_SIZE seats),
//                  then GLM's shadow (grader/judge-heat.ts judgeHeatShadowOf: the Swiss judge, listed last)
//   the plan       judgeBarPlan: for each subject in setup order, each game k from 0 to games - 1 and each seat in that
//                  order, two calls of stage `bar`, round k, the pair (a: the subject, b: the bar) and `judge` the seat's
//                  index into `judges`: first in slot order `ab` (the subject in slot A), then `ba` (the bar in slot A).
//                  No seed: every subject plays both orders of every game, so nothing is drawn
//   a game         the two calls of one seat, judge-heat's v2 fold (judgeGamePoints): the subject's tenths of each call
//                  summed, 0 to 20, a call with no verdict giving each side 5; its result judgeGameResultOf of that, and
//                  the seat's judge. The record's `games` are these raw games, one a seat, the shadow's included
//   the verdict    a subject's points summed over its `games` games. A one-judge game scores its one seat's a_points; a
//                  panel game scores judgePanelPointsOf over the panel seats whose two calls both carry a verdict (three
//                  the median, two their mean rounded toward 10, one its own, none 10), the shadow's game recorded and
//                  never scored, as grader/judge-heat.ts judgeHeatScoredGames folds a playoff slot. max = 20 x games, and
//                  the subject beats the bar iff points > 10 x games: exactly half does not (judgeBarVerdictsOf)
//   the record     JudgeBarRecord: the format, the setup, every call in plan order (judge-heat's JudgeHeatCall but its
//                  stage `bar`, its margin always present and its judge always named), the calls' other sends
//                  (`spares`, judge-heat's JudgeHeatSpare under its rules: absent, never empty, when none), the games, the
//                  verdicts in subject order, the totals (judge-heat's: counts, usage, price and timing, spares'
//                  attempts counted) and the calls with no verdict. judgeBarRecordIssues holds the setup, re-derives the
//                  plan and holds every call to its place in it, then re-derives the games, verdicts, totals and invalid
//                  calls from the calls, each byte for byte
//   the resume     judgeBarResumeKey(setup, plan): sha256 of the canonical JSON of the format, the setup and whatever
//                  else the calls depend on (the job names its bundle and prompt); judgeBarKeptIssue holds kept calls
//                  and spares to a prefix of the plan
//
// An invalid share over the judge's invalid_share_max is the job's to refuse (it is retried as the platform's fault and
// never becomes a verdict); under it, a call with no verdict scores as in the playoff. Faults are the house's
// (judge-heat's JudgeHeatError), never an entry's.

import { z } from 'zod';
import { PROGRAM_JUDGE_BAR_MAX_GAMES, PROGRAM_JUDGE_BAR_MAX_PLACES, PROGRAM_JUDGE_BAR_NAME_MAX } from '../contracts/competition.ts';
import { Sha256Hex } from '../contracts/primitives.ts';
import { ScrapeEntryId } from '../contracts/scrape.ts';
import { JUDGE_PANEL_SIZE, judgePanelDraw, judgePanelOrder, judgePanelPoolIssues, judgePanelPoolSha256 } from '../server/judging/panel.ts';
import { JudgeOfHeat, type JudgeOfHeatT } from '../server/judging/pool.ts';
import { canonicalJson, compareCodeUnits, sha256Hex } from '../sim/canonical.ts';
import {
  JUDGE_GAME_POINTS,
  JUDGE_HEAT_FORMAT,
  JUDGE_HEAT_FORMAT_V4,
  JUDGE_HEAT_FORMAT_V5,
  JUDGE_HEAT_FORMAT_V6,
  JUDGE_HEAT_MAX_SENDS,
  JUDGE_HEAT_PANEL_SEAT_WEIGHT,
  JUDGE_HEAT_PANEL_SWISS_WEIGHT,
  JUDGE_GAME_RESULTS,
  JUDGE_SLOT_ORDERS,
  JudgeHeatCall,
  JudgeHeatError,
  JudgeHeatJudgeView,
  JudgeHeatPanel,
  JudgeHeatSpare,
  JudgeHeatTotals,
  judgeCallTenths,
  judgeGameResultOf,
  judgeHeatCallIssues,
  judgeHeatCallOf,
  judgeHeatPanelFormat,
  judgeHeatShadowOf,
  judgeHeatSpareIssues,
  judgeHeatTimingOf,
  judgePanelPointsOf,
  type JudgeCallResultT,
  type JudgeHeatCallT,
  type JudgeHeatPanelT,
  type JudgeHeatSpareT,
  type JudgeHeatTotalsT,
  type JudgeSlotOrderT,
} from './judge-heat.ts';

// ---------------------------------------------------------------- constants

/** The bar record's format (the header's record). */
export const JUDGE_BAR_FORMAT = 'agent-fun/judge-bar/v1';
/** Every bar call's and game's stage (the header's plan): never one of a heat's JUDGE_CALL_STAGES. */
export const JUDGE_BAR_STAGE = 'bar';
// The record's bounds are the bundle's own (contracts/competition.ts), so a record read from outside plans no more than
// a bundle may: at most PROGRAM_JUDGE_BAR_MAX_GAMES games a subject, PROGRAM_JUDGE_BAR_MAX_PLACES subjects (the last paid
// place at most, so at most subjects x games x 2 calls, x4 on a panel), and a name of PROGRAM_JUDGE_BAR_NAME_MAX at most.
/**
 * The final heat formats a bar is judged like (the header's setup): a final's that writes margins, so its playoff's fold
 * is judgeGamePoints (v2, v4) or the panel's median (v5, v6). v1 finals are written no more; v3 is the ladder's alone.
 */
export const JUDGE_BAR_FINAL_FORMATS = [JUDGE_HEAT_FORMAT, JUDGE_HEAT_FORMAT_V4, JUDGE_HEAT_FORMAT_V5, JUDGE_HEAT_FORMAT_V6] as const;
export type JudgeBarFinalFormatT = (typeof JUDGE_BAR_FINAL_FORMATS)[number];

const HALF = JUDGE_GAME_POINTS / 2;
const LOWER_UUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/;

// ---------------------------------------------------------------- the record

/** The settled final heat record a bar is judged like: its blob's sha256 and its format. */
export const JudgeBarFinalHeat = z.strictObject({
  sha256: Sha256Hex,
  format: z.enum(JUDGE_BAR_FINAL_FORMATS),
});
export type JudgeBarFinalHeatT = z.infer<typeof JudgeBarFinalHeat>;

/**
 * The bar (the header's setup), the bundle's harness.judge.bar: its name (one line), the sealed bar dir's tree digest,
 * the bar artifact's sha256 and size, and the games each subject plays it.
 */
export const JudgeBarBar = z.strictObject({
  name: z
    .string()
    .min(1)
    .max(PROGRAM_JUDGE_BAR_NAME_MAX)
    .refine((s) => /\S/.test(s) && !/[\r\n\u2028\u2029]/.test(s), 'one line: not blank, no line break'),
  bar_sha256: Sha256Hex,
  artifact_sha256: Sha256Hex,
  artifact_bytes: z.int().min(0),
  games: z.int().min(1).max(PROGRAM_JUDGE_BAR_MAX_GAMES),
});
export type JudgeBarBarT = z.infer<typeof JudgeBarBar>;

/** One subject (the header's setup): a distinct judged artifact, its size and the entries whose artifact it is. */
export const JudgeBarSubject = z.strictObject({
  artifact_sha256: Sha256Hex,
  artifact_bytes: z.int().min(0),
  entries: z.array(ScrapeEntryId).min(1),
});
export type JudgeBarSubjectT = z.infer<typeof JudgeBarSubject>;

/** What a bar heat is before its calls (the header's setup): everything its plan is drawn from. */
export const JudgeBarSetup = z.strictObject({
  /** The final phase's id, a lowercase uuid. */
  phase_id: z.string().regex(LOWER_UUID, 'expected a lowercase uuid'),
  final_heat: JudgeBarFinalHeat,
  bar: JudgeBarBar,
  /** In place order, one per distinct artifact. */
  subjects: z.array(JudgeBarSubject).min(1).max(PROGRAM_JUDGE_BAR_MAX_PLACES),
  /** The final record's `judges`, verbatim. */
  judges: z.array(JudgeOfHeat).min(1),
  /** The final record's `panel`, verbatim: a v5 or v6 final's alone. */
  panel: JudgeHeatPanel.optional(),
  /** The judge prompt's sha256. */
  prompt_sha256: Sha256Hex,
  /** A dossier final judged on views: the policy and each subject's and the bar's artifact to its view blob. */
  judge_view: JudgeHeatJudgeView.optional(),
});
export type JudgeBarSetupT = z.infer<typeof JudgeBarSetup>;

/**
 * One bar call (the header's record): judge-heat's JudgeHeatCall, field for field, but its stage `bar`, its round the
 * game's index, its `judge` always named (a seat's index into the setup's judges) and its margin always present (null
 * exactly with no verdict).
 */
export const JudgeBarCall = JudgeHeatCall.extend({
  stage: z.literal(JUDGE_BAR_STAGE),
  judge: z.int().min(0),
  margin: JudgeHeatCall.shape.margin.unwrap(),
});
export type JudgeBarCallT = z.infer<typeof JudgeBarCall>;

/** One seat's game (the header's game): the two calls' fold, the subject's twentieths and the seat's judge. */
export const JudgeBarGame = z.strictObject({
  stage: z.literal(JUDGE_BAR_STAGE),
  round: z.int().min(0),
  a: Sha256Hex,
  b: Sha256Hex,
  result: z.enum(JUDGE_GAME_RESULTS),
  a_points: z.int().min(0).max(JUDGE_GAME_POINTS),
  judge: z.int().min(0),
});
export type JudgeBarGameT = z.infer<typeof JudgeBarGame>;

/** A subject's verdict (the header's verdict): its points over its games, the most it could take, and whether it beats the bar. */
export const JudgeBarVerdict = z.strictObject({
  artifact_sha256: Sha256Hex,
  entries: z.array(ScrapeEntryId).min(1),
  points: z.int().min(0),
  max: z.int().min(1),
  beats: z.boolean(),
});
export type JudgeBarVerdictT = z.infer<typeof JudgeBarVerdict>;

/** The bar record (the header's record): canonical JSON, stored as a blob named by its sha256. */
export const JudgeBarRecord = z.strictObject({
  format: z.literal(JUDGE_BAR_FORMAT),
  setup: JudgeBarSetup,
  /** Every call, in plan order. */
  calls: z.array(JudgeBarCall),
  /** The calls' other sends, ordered by call, then send; absent, never empty, when there are none. */
  spares: z.array(JudgeHeatSpare).min(1).optional(),
  /** Every seat's game, two calls each, in call order. */
  games: z.array(JudgeBarGame),
  /** One a subject, in subject order. */
  verdicts: z.array(JudgeBarVerdict),
  totals: JudgeHeatTotals,
  /** The calls with no verdict. */
  invalid_calls: z.int().min(0),
});
export type JudgeBarRecordT = z.infer<typeof JudgeBarRecord>;

/** A call the bar heat makes (the header's plan). */
export interface JudgeBarPlannedCallT {
  stage: typeof JUDGE_BAR_STAGE;
  round: number;
  a: string;
  b: string;
  slot_order: JudgeSlotOrderT;
  judge: number;
}

function doesNotHold(issues: readonly string[]): JudgeHeatError {
  return new JudgeHeatError(`the bar record does not hold: ${issues.join('; ')}`);
}

function shapeIssues(error: z.ZodError, root: string): string[] {
  return error.issues.map((i) => `${i.path.join('.') || root}: ${i.message}`);
}

// ---------------------------------------------------------------- the setup and the seats

/** Whether the final the setup judges like is a panel final's (v5 or v6). */
function panelled(setup: Pick<JudgeBarSetupT, 'final_heat'>): boolean {
  return judgeHeatPanelFormat(setup.final_heat.format);
}

/**
 * The seats of a game (the header's seats), as indices into the setup's judges, in the order each game plays them: a
 * one-judge final's [0]; a panel final's panel seats 0 to JUDGE_PANEL_SIZE - 1, then the shadow (judgeHeatShadowOf).
 * RangeError on a panel final's setup that names no panel.
 */
export function judgeBarSeatsOf(setup: Pick<JudgeBarSetupT, 'final_heat' | 'panel'>): number[] {
  if (!panelled(setup)) return [0];
  const seats = Array.from({ length: JUDGE_PANEL_SIZE }, (_, k) => k);
  return [...seats, judgeHeatShadowOf({ format: setup.final_heat.format, panel: setup.panel })];
}

/** The calls a bar heat makes: subjects x games x seats x 2 (judgeBarPlan's length). */
export function judgeBarPlannedCalls(setup: Pick<JudgeBarSetupT, 'final_heat' | 'panel' | 'bar' | 'subjects'>): number {
  return setup.subjects.length * setup.bar.games * judgeBarSeatsOf(setup).length * 2;
}

/**
 * What does not hold in a parsed setup's panel and judges (the header's seats), each issue naming where: a panel exactly
 * on a v5 or v6 final, its pool hashing to pool_sha256 (judgePanelPoolSha256) with no judgePanelPoolIssues, its draw
 * judgePanelDraw of the pool's sha256 and the beacon's signature and its order judgePanelOrder of that draw; on v5 the
 * judges [the three seated members in drawn order, then the Swiss judge], on v6 [every pool member in drawn order, then
 * the Swiss judge], each member's judge via panel on openrouter with the member's model, at most its output tokens and
 * exactly its temperature (v6: at JUDGE_HEAT_PANEL_SEAT_WEIGHT), the Swiss judge via overflow at
 * JUDGE_HEAT_PANEL_SWISS_WEIGHT; a one-judge final's exactly one judge, not via panel. Every openrouter judge names its
 * pinned endpoints. grader/judge-heat.ts holds the final record's own setup the same way; these are its copies.
 */
function judgesIssuesOf(setup: JudgeBarSetupT): string[] {
  const issues: string[] = [];
  const format = setup.final_heat.format;
  const judges = setup.judges;
  judges.forEach((j, k) => {
    if (j.door === 'openrouter' && j.provider === undefined) issues.push(`judges.${k}.provider: an openrouter judge names its pinned endpoints, or its requests cannot be rebuilt`);
  });
  if (!panelled(setup)) {
    if (setup.panel !== undefined) issues.push(`panel: a ${JUDGE_HEAT_FORMAT_V5} or ${JUDGE_HEAT_FORMAT_V6} final's alone, and this bar is judged like a ${format} final`);
    if (judges.length !== 1) issues.push(`judges: a ${format} final's playoff is judged by its one judge, and ${judges.length} are listed`);
    judges.forEach((j, k) => {
      if (j.via === 'panel') issues.push(`judges.${k}.via: a panel judge is a ${JUDGE_HEAT_FORMAT_V5} or ${JUDGE_HEAT_FORMAT_V6} final's alone, and this bar is judged like a ${format} final`);
    });
    return issues;
  }
  const panel = setup.panel;
  if (panel === undefined) return [...issues, `panel: a bar judged like a ${format} final names that final's drawn panel`];
  issues.push(...panelIssuesOf(panel));
  const order = judgePanelOrder(panel.draw, panel.pool.members.length);
  const dealt = format === JUDGE_HEAT_FORMAT_V6;
  const members = dealt ? panel.pool.members.length : JUDGE_PANEL_SIZE;
  if (judges.length !== members + 1) {
    issues.push(
      `judges: a ${format} final lists ${dealt ? `the pool's ${members} members in the draw's order` : `the ${members} seated members`}, then the Swiss judge (${members + 1} judges), and ${judges.length} are listed`,
    );
  }
  for (let k = 0; k < members && k < judges.length; k++) {
    const j = judges[k]!;
    const m = panel.pool.members[order[k]!];
    const where = `judges.${k}`;
    if (j.via !== 'panel') issues.push(`${where}.via: the draw's place ${k} is judged via panel, and this judge is via ${j.via}`);
    if (j.door !== 'openrouter') issues.push(`${where}.door: every panel call goes to OpenRouter, and this judge is on ${j.door}`);
    if (m === undefined) continue;
    if (j.model !== m.model) issues.push(`${where}.model: the draw's place ${k} is pool member ${order[k]} (${m.model}), not ${j.model}`);
    if (j.max_output_tokens > m.max_output_tokens) issues.push(`${where}.max_output_tokens: ${m.model} is asked at most the member's ${m.max_output_tokens} output tokens, and this judge asks ${j.max_output_tokens}`);
    if (j.temperature !== m.temperature) issues.push(`${where}.temperature: ${m.model} is asked the member's temperature ${m.temperature ?? '(none named)'}, and this judge asks ${j.temperature ?? '(none named)'}`);
    if (dealt && j.weight !== JUDGE_HEAT_PANEL_SEAT_WEIGHT) issues.push(`${where}.weight: a pool member's weight is ${JUDGE_HEAT_PANEL_SEAT_WEIGHT}, and this judge's ${j.weight}`);
  }
  if (judges.length > members) {
    const k = judges.length - 1;
    const swiss = judges[k]!;
    if (swiss.via !== 'overflow') issues.push(`judges.${k}.via: the Swiss judge (the shadow), listed last, is via overflow, and this judge is via ${swiss.via}`);
    if (swiss.weight !== JUDGE_HEAT_PANEL_SWISS_WEIGHT) issues.push(`judges.${k}.weight: the Swiss judge's weight is ${JUDGE_HEAT_PANEL_SWISS_WEIGHT}, and this judge's ${swiss.weight}`);
  }
  return issues;
}

/** A panel's own issues, by sha256 alone (the beacon's BLS signature is the regrade's and the kit verifier's). */
function panelIssuesOf(panel: JudgeHeatPanelT): string[] {
  const issues: string[] = [];
  const sha = judgePanelPoolSha256(panel.pool);
  if (sha !== panel.pool_sha256) issues.push(`panel.pool_sha256: the pool hashes to ${sha}, not ${panel.pool_sha256}`);
  for (const i of judgePanelPoolIssues(panel.pool)) issues.push(`panel.pool: ${i}`);
  const draw = judgePanelDraw(panel.pool_sha256, panel.beacon.signature);
  if (panel.draw !== draw) issues.push(`panel.draw: the pool's sha256 and the beacon's signature draw ${draw}, not ${panel.draw}`);
  const order = judgePanelOrder(draw, panel.pool.members.length);
  if (canonicalJson(panel.order) !== canonicalJson(order)) issues.push(`panel.order: the draw orders the pool ${canonicalJson(order)}, not ${canonicalJson(panel.order)}`);
  return issues;
}

/** What does not hold in a parsed setup (the header's setup and seats), each issue naming where. */
function setupIssuesOf(setup: JudgeBarSetupT): string[] {
  const issues: string[] = [];
  const bar = setup.bar.artifact_sha256;
  const artifacts = new Set<string>();
  const entries = new Set<string>();
  setup.subjects.forEach((s, i) => {
    if (s.artifact_sha256 === bar) issues.push(`subjects.${i}.artifact_sha256: the bar's own artifact never plays the bar`);
    if (artifacts.has(s.artifact_sha256)) issues.push(`subjects.${i}.artifact_sha256: one subject a distinct artifact, and ${s.artifact_sha256} is another subject's too`);
    artifacts.add(s.artifact_sha256);
    if (!s.entries.every((e, k) => k === 0 || compareCodeUnits(s.entries[k - 1]!, e) < 0)) issues.push(`subjects.${i}.entries: distinct, in code-unit order`);
    for (const e of s.entries) {
      if (entries.has(e)) issues.push(`subjects.${i}.entries: ${e} is another subject's too`);
      entries.add(e);
    }
  });
  if (setup.judge_view !== undefined) {
    const views = setup.judge_view.views;
    const carried = [...artifacts, bar];
    for (const a of carried) if (views[a] === undefined) issues.push(`judge_view.views: names no view of ${a}, which a call carries`);
    for (const a of Object.keys(views)) if (!carried.includes(a)) issues.push(`judge_view.views.${a}: neither the bar nor a subject`);
  }
  issues.push(...judgesIssuesOf(setup));
  return issues;
}

/** What does not hold in a setup (none when it holds): its shape, then its subjects, views, panel and judges. Each issue names where. */
export function judgeBarSetupIssues(raw: JudgeBarSetupT): string[] {
  const parsed = JudgeBarSetup.safeParse(raw);
  if (!parsed.success) return shapeIssues(parsed.error, '(setup)');
  return setupIssuesOf(parsed.data);
}

// ---------------------------------------------------------------- the plan

/** The plan of a setup that holds (the header's plan). */
function planOf(setup: JudgeBarSetupT): JudgeBarPlannedCallT[] {
  const seats = judgeBarSeatsOf(setup);
  const b = setup.bar.artifact_sha256;
  const out: JudgeBarPlannedCallT[] = [];
  for (const s of setup.subjects) {
    for (let round = 0; round < setup.bar.games; round++) {
      for (const judge of seats) {
        for (const slot_order of JUDGE_SLOT_ORDERS) out.push({ stage: JUDGE_BAR_STAGE, round, a: s.artifact_sha256, b, slot_order, judge });
      }
    }
  }
  return out;
}

/**
 * Every call of the bar heat, in the order sent (the header's plan): for each subject, each game k and each seat, the
 * subject in slot A (`ab`), then the bar in slot A (`ba`). JudgeHeatError when the setup does not hold.
 */
export function judgeBarPlan(setup: JudgeBarSetupT): JudgeBarPlannedCallT[] {
  const issues = judgeBarSetupIssues(setup);
  if (issues.length > 0) throw new JudgeHeatError(`the bar setup does not hold: ${issues.join('; ')}`);
  return planOf(JudgeBarSetup.parse(setup));
}

/**
 * The key kept calls are resumed under (the header's resume): sha256 of the canonical JSON of the format, the setup
 * (its judges and panel included: a bar's are the final's, fixed before it) and the caller's `plan` (whatever else the
 * calls depend on: the job names its bundle and prompt).
 */
export function judgeBarResumeKey(setup: JudgeBarSetupT, plan: unknown): string {
  return sha256Hex(canonicalJson({ format: JUDGE_BAR_FORMAT, setup: JudgeBarSetup.parse(setup), plan }));
}

/**
 * The bar call kept for `planned`, from what grader/judge-call.ts answered for it: judge-heat's judgeHeatCallOf (its
 * pair, slot order, margin and attempts held), its stage `bar`. JudgeHeatError as judgeHeatCallOf throws it.
 */
export function judgeBarCallOf(planned: JudgeBarPlannedCallT, result: JudgeCallResultT): JudgeBarCallT {
  // judgeHeatCallOf never reads the stage but to copy it: a heat stage stands in, and the bar's goes back on.
  const call = judgeHeatCallOf({ ...planned, stage: 'playoff' }, result);
  const parsed = JudgeBarCall.safeParse({ ...call, stage: JUDGE_BAR_STAGE });
  if (!parsed.success) throw new JudgeHeatError(`the bar call is not one: ${shapeIssues(parsed.error, '(call)').join('; ')}`);
  return parsed.data;
}

// ---------------------------------------------------------------- the calls

/** judgeHeatCallIssues over a bar call: it never reads the stage, so a heat call's rules are the bar call's. */
function callIssues(c: JudgeBarCallT): string[] {
  return judgeHeatCallIssues(c as unknown as JudgeHeatCallT);
}

function plannedWords(p: JudgeBarPlannedCallT): string {
  return `subject ${p.a}'s game ${p.round} on judge ${p.judge}, ${p.slot_order === 'ab' ? 'the subject' : 'the bar'} in slot A (slot order ${p.slot_order})`;
}

/**
 * What does not hold in calls and their spares against a plan (none when they hold), each issue naming where: every call
 * holds (judgeHeatCallIssues) and is the plan's call at its place (round, pair, slot order and judge), no more calls
 * than the plan; an attempt names its `provider` only on an openrouter judge; the spares as judge-heat holds them (each
 * one's fields, each naming a listed call, ordered by call, then send, at most JUDGE_HEAT_MAX_SENDS - 1 a call).
 */
function callsIssuesOf(setup: JudgeBarSetupT, plan: readonly JudgeBarPlannedCallT[], calls: readonly JudgeBarCallT[], spares: readonly JudgeHeatSpareT[]): string[] {
  const issues: string[] = [];
  const doorOf = (c: JudgeBarCallT | undefined): JudgeOfHeatT['door'] | null => (c === undefined ? null : (setup.judges[c.judge]?.door ?? null));
  const providers = (where: string, attempts: readonly { provider?: string }[], c: JudgeBarCallT | undefined): void => {
    attempts.forEach((t, n) => {
      if (t.provider !== undefined && doorOf(c) !== 'openrouter') issues.push(`${where}.attempts.${n}.provider: only an attempt an openrouter judge was sent names who served it`);
    });
  };
  calls.forEach((c, i) => {
    issues.push(...callIssues(c).map((issue) => `calls.${i}.${issue}`));
    const p = plan[i];
    if (p === undefined) return;
    for (const key of ['round', 'a', 'b', 'slot_order', 'judge'] as const) {
      if (c[key] !== p[key]) issues.push(`calls.${i}.${key}: the bar plays ${plannedWords(p)} here, ${key} ${String(p[key])}, not ${String(c[key])}`);
    }
    providers(`calls.${i}`, c.attempts, c);
  });
  if (calls.length > plan.length) issues.push(`calls: the bar plays ${plan.length} calls, and ${calls.length} are listed`);
  const perCall = new Map<number, number>();
  spares.forEach((s, k) => {
    issues.push(...judgeHeatSpareIssues(s).map((issue) => `spares.${k}.${issue}`));
    if (s.call >= calls.length) issues.push(`spares.${k}.call: ${s.call} names no call: ${calls.length} are listed`);
    const prev = spares[k - 1];
    if (prev !== undefined && (prev.call > s.call || (prev.call === s.call && prev.send >= s.send))) {
      issues.push(`spares.${k}: the spares are ordered by call, then send, each send of a call once (call ${s.call} send ${s.send} after call ${prev.call} send ${prev.send})`);
    }
    const n = (perCall.get(s.call) ?? 0) + 1;
    perCall.set(s.call, n);
    if (n === JUDGE_HEAT_MAX_SENDS) issues.push(`spares.${k}.call: call ${s.call} has at most ${JUDGE_HEAT_MAX_SENDS - 1} spares, its decision the ${JUDGE_HEAT_MAX_SENDS}th of its sends`);
    providers(`spares.${k}`, s.attempts, calls[s.call]);
  });
  return issues;
}

/**
 * The first reason kept calls and spares (a partial's) are not a prefix of the bar heat's (null when they are): the setup
 * holds (judgeBarSetupIssues), and each kept call and spare holds as judgeBarRecordIssues holds a record's. Kept calls
 * that pass are the plan's first ones: the attempt goes on from the next.
 */
export function judgeBarKeptIssue(setup: JudgeBarSetupT, kept: readonly JudgeBarCallT[], spares: readonly JudgeHeatSpareT[] = []): string | null {
  const setupIssues = judgeBarSetupIssues(setup);
  if (setupIssues.length > 0) return `setup.${setupIssues[0]!}`;
  const parsedCalls: JudgeBarCallT[] = [];
  for (const [i, c] of kept.entries()) {
    const parsed = JudgeBarCall.safeParse(c);
    if (!parsed.success) return `calls.${i}.${shapeIssues(parsed.error, '(call)')[0] ?? 'malformed'}`;
    parsedCalls.push(parsed.data);
  }
  const parsedSpares: JudgeHeatSpareT[] = [];
  for (const [k, s] of spares.entries()) {
    const parsed = JudgeHeatSpare.safeParse(s);
    if (!parsed.success) return `spares.${k}.${shapeIssues(parsed.error, '(spare)')[0] ?? 'malformed'}`;
    parsedSpares.push(parsed.data);
  }
  const parsedSetup = JudgeBarSetup.parse(setup);
  return callsIssuesOf(parsedSetup, planOf(parsedSetup), parsedCalls, parsedSpares)[0] ?? null;
}

// ---------------------------------------------------------------- games, verdicts, totals

/** The subject's twentieths of a seat's game from its two calls: judge-heat's v2 fold (a call with no verdict, 5 each). */
function pointsOf(first: JudgeBarCallT, second: JudgeBarCallT): number {
  if (first.a !== second.a || first.b !== second.b) throw new RangeError(`a game's two calls judge one pair, not ${first.a}/${first.b} and ${second.a}/${second.b}`);
  return judgeCallTenths(first, first.a) + judgeCallTenths(second, first.a);
}

/** The games of calls that run two a seat's game, in their order (the header's game). */
function gamesOf(calls: readonly JudgeBarCallT[]): JudgeBarGameT[] {
  const out: JudgeBarGameT[] = [];
  for (let k = 0; k + 1 < calls.length; k += 2) {
    const first = calls[k]!;
    const aPoints = pointsOf(first, calls[k + 1]!);
    out.push({ stage: JUDGE_BAR_STAGE, round: first.round, a: first.a, b: first.b, result: judgeGameResultOf(aPoints), a_points: aPoints, judge: first.judge });
  }
  return out;
}

/**
 * The verdicts of calls laid out as a setup that holds plans them (the header's verdict), one a subject in setup order:
 * a one-judge game its seat's points, a panel game judgePanelPointsOf over the panel seats whose two calls both carry a
 * verdict (the shadow's never read), summed over the games; max 20 x games; beats exactly when points > 10 x games.
 */
function verdictsOf(setup: JudgeBarSetupT, calls: readonly JudgeBarCallT[]): JudgeBarVerdictT[] {
  const seats = judgeBarSeatsOf(setup).length;
  const panel = panelled(setup);
  const games = setup.bar.games;
  return setup.subjects.map((s, i) => {
    let points = 0;
    for (let k = 0; k < games; k++) {
      const at = (i * games + k) * seats * 2;
      const seat = (n: number): [JudgeBarCallT, JudgeBarCallT] => [calls[at + 2 * n]!, calls[at + 2 * n + 1]!];
      if (!panel) {
        points += pointsOf(...seat(0));
        continue;
      }
      const counted: number[] = [];
      for (let n = 0; n < JUDGE_PANEL_SIZE; n++) {
        const [first, second] = seat(n);
        if (first.verdict !== null && second.verdict !== null) counted.push(pointsOf(first, second));
      }
      points += judgePanelPointsOf(counted);
    }
    return { artifact_sha256: s.artifact_sha256, entries: [...s.entries], points, max: JUDGE_GAME_POINTS * games, beats: points > HALF * games };
  });
}

const USAGE_KEYS = ['input', 'output', 'cache_read', 'cache_write_5m', 'cache_write_1h', 'reasoning'] as const;
type UsageT = JudgeHeatTotalsT['usage'];

function usageSum(all: readonly (UsageT | null)[]): UsageT {
  const sum: UsageT = { input: 0, output: 0, cache_read: 0, cache_write_5m: 0, cache_write_1h: 0, reasoning: 0 };
  for (const u of all) if (u !== null) for (const k of USAGE_KEYS) sum[k] += u[k];
  return sum;
}

/** The totals (judge-heat's): the calls, every attempt sent (the spares' too) and their usage and price summed, and the timing they name. */
function totalsOf(calls: readonly JudgeBarCallT[], spares: readonly JudgeHeatSpareT[]): JudgeHeatTotalsT {
  const attempts = [...calls.flatMap((c) => c.attempts), ...spares.flatMap((s) => s.attempts)];
  let micro = 0n;
  for (const t of attempts) if (t.micro_usd !== null) micro += BigInt(t.micro_usd);
  const totals: JudgeHeatTotalsT = { calls: calls.length, attempts: attempts.length, usage: usageSum(attempts.map((t) => t.usage)), micro_usd: micro.toString() };
  const timing = judgeHeatTimingOf(calls, spares);
  return timing === null ? totals : { ...totals, ...timing };
}

/**
 * The verdicts a record's calls make (the header's verdict), one a subject in setup order: what judgeBarRecordIssues
 * holds its `verdicts` to. JudgeHeatError when its setup does not hold, or its calls are not its plan's, all of them.
 */
export function judgeBarVerdictsOf(record: Pick<JudgeBarRecordT, 'setup' | 'calls'>): JudgeBarVerdictT[] {
  const setup = JudgeBarSetup.safeParse(record.setup);
  if (!setup.success) throw doesNotHold(shapeIssues(setup.error, 'setup').map((i) => `setup.${i}`));
  const calls = z.array(JudgeBarCall).safeParse(record.calls);
  if (!calls.success) throw doesNotHold(shapeIssues(calls.error, 'calls').map((i) => `calls.${i}`));
  const issues = setupIssuesOf(setup.data).map((i) => `setup.${i}`);
  if (issues.length > 0) throw doesNotHold(issues);
  const plan = planOf(setup.data);
  issues.push(...callsIssuesOf(setup.data, plan, calls.data, []));
  if (calls.data.length !== plan.length) issues.push(`calls: the bar plays ${plan.length} calls, and ${calls.data.length} are listed`);
  if (issues.length > 0) throw doesNotHold(issues);
  return verdictsOf(setup.data, calls.data);
}

// ---------------------------------------------------------------- issues, records, parsing

/**
 * What does not hold in a record (none when it holds), each issue naming where: its shape; its setup
 * (judgeBarSetupIssues); every call held and at its place in the plan re-derived from the setup, every planned call
 * listed; the attempts' providers and the spares; then the games, verdicts, totals and invalid calls re-derived from the
 * calls, each byte for byte.
 */
export function judgeBarRecordIssues(raw: JudgeBarRecordT): string[] {
  const parsed = JudgeBarRecord.safeParse(raw);
  if (!parsed.success) return shapeIssues(parsed.error, '(record)');
  return parsedRecordIssues(parsed.data);
}

function parsedRecordIssues(r: JudgeBarRecordT): string[] {
  const issues = setupIssuesOf(r.setup).map((i) => `setup.${i}`);
  if (issues.length > 0) return issues;
  const plan = planOf(r.setup);
  const spares = r.spares ?? [];
  issues.push(...callsIssuesOf(r.setup, plan, r.calls, spares));
  if (r.calls.length < plan.length) issues.push(`calls: the bar plays ${plan.length} calls, and ${r.calls.length} are listed`);
  if (issues.length > 0) return issues;
  const games = gamesOf(r.calls);
  if (games.length !== r.games.length) issues.push(`games: the calls make ${games.length} games, and ${r.games.length} are listed`);
  else {
    const at = games.findIndex((g, i) => canonicalJson(g) !== canonicalJson(r.games[i]));
    if (at !== -1) issues.push(`games.${at}: the calls make ${canonicalJson(games[at])} here`);
  }
  const verdicts = verdictsOf(r.setup, r.calls);
  if (verdicts.length !== r.verdicts.length) issues.push(`verdicts: one a subject, ${verdicts.length}, and ${r.verdicts.length} are listed`);
  else {
    verdicts.forEach((v, i) => {
      if (canonicalJson(v) !== canonicalJson(r.verdicts[i])) issues.push(`verdicts.${i}: the calls make ${canonicalJson(v)} here`);
    });
  }
  const totals = totalsOf(r.calls, spares);
  if (canonicalJson(totals) !== canonicalJson(r.totals)) issues.push(`totals: the calls and their spares total ${canonicalJson(totals)}`);
  const invalid = r.calls.filter((c) => c.verdict === null).length;
  if (invalid !== r.invalid_calls) issues.push(`invalid_calls: ${invalid} calls have no verdict, not ${r.invalid_calls}`);
  return issues;
}

/**
 * The record of a bar heat whose calls are all made (the header's record): the setup, `calls` in plan order, the games,
 * verdicts, totals and invalid calls derived from them, and `spares` (absent when none). JudgeHeatError when it does not
 * hold (judgeBarRecordIssues): the setup does not, or the calls are not the plan's, all of them.
 */
export function judgeBarRecordOf(setup: JudgeBarSetupT, calls: readonly JudgeBarCallT[], spares: readonly JudgeHeatSpareT[] = []): JudgeBarRecordT {
  const verdicts = judgeBarVerdictsOf({ setup, calls: [...calls] });
  const parsedSetup = JudgeBarSetup.parse(setup);
  const parsedCalls = z.array(JudgeBarCall).parse(calls);
  const record = {
    format: JUDGE_BAR_FORMAT,
    setup: parsedSetup,
    calls: parsedCalls,
    ...(spares.length === 0 ? {} : { spares: [...spares] }),
    games: gamesOf(parsedCalls),
    verdicts,
    totals: totalsOf(parsedCalls, spares),
    invalid_calls: parsedCalls.filter((c) => c.verdict === null).length,
  };
  const parsed = JudgeBarRecord.safeParse(record);
  if (!parsed.success) throw doesNotHold(shapeIssues(parsed.error, '(record)'));
  const issues = parsedRecordIssues(parsed.data);
  if (issues.length > 0) throw doesNotHold(issues);
  return parsed.data;
}

/** The record's canonical JSON and its sha256: the blob it is stored as. */
export function judgeBarRecordDigest(record: JudgeBarRecordT): { json: string; sha256: string } {
  const json = canonicalJson(JudgeBarRecord.parse(record));
  return { json, sha256: sha256Hex(json) };
}

/**
 * A record as stored (canonical JSON text or bytes), parsed and held (judgeBarRecordIssues). JudgeHeatError when it is no
 * bar record that holds: a judge heat or contender record, of any format, is refused by its format.
 */
export function parseJudgeBarRecord(stored: string | Uint8Array): JudgeBarRecordT {
  let raw: unknown;
  try {
    raw = JSON.parse(typeof stored === 'string' ? stored : new TextDecoder('utf-8', { fatal: true }).decode(stored));
  } catch (err) {
    throw new JudgeHeatError(`the bar record is not JSON: ${(err as Error).message}`);
  }
  const format = (raw as { format?: unknown } | null)?.format;
  if (format !== JUDGE_BAR_FORMAT) throw new JudgeHeatError(`the bar record's format is ${JSON.stringify(format)}, not ${JUDGE_BAR_FORMAT}`);
  const parsed = JudgeBarRecord.safeParse(raw);
  if (!parsed.success) throw new JudgeHeatError(`the bar record is not one: ${shapeIssues(parsed.error, '(record)')[0] ?? 'malformed'}`);
  const issues = parsedRecordIssues(parsed.data);
  if (issues.length > 0) throw new JudgeHeatError(`the bar record does not hold: ${issues[0]}`);
  return parsed.data;
}
